
public class StringDescriptor implements KeyDescriptor<String> {
  /*
   * Todo
   */
  
  @Override public int buckets () {
    /*
     * Todo
     */
  }

  @Override public int digits () {
    /*
     * Todo
     */
  }

  @Override public int key (String element, int digit) {
    /*
     * Todo
     */
  }

}
