
public class IntegerDescriptor implements KeyDescriptor<Integer> {
  @Override public int buckets () {
    /*
     * Todo
     */
  }

  @Override public int digits () {
    /*
     * Todo
     */
  }

  @Override public int key (Integer element, int digit) {
    /*
     * Todo
     */
  }

}
