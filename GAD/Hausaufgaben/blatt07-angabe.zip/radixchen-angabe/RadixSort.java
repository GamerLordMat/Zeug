
public class RadixSort<K> {
  /*
   * Todo
   */

  private void kSort(K[] elements, int digit) {
    /*
     * Todo
     */
  }
  
  public void sort(K[] elements) {
    /*
     * Todo
     */
  }

  /**
   * Diese Methode sortiert ein Feld mittels RadixSort.
   * 
   * @param keyDescriptor ein Objekt zur Ermittelung von Informationen über die zu sortierenden Elemente
   * @param elements die zu sortierenden Elemente
   */
  public static <K> void sort(KeyDescriptor<K> keyDescriptor, K[] elements) {
    RadixSort<K> radixSort = new RadixSort<K>(keyDescriptor);
    radixSort.sort(elements);
  }
}
