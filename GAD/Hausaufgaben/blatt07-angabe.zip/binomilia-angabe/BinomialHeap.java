
public class BinomialHeap {
  /*
   * Todo
   */
  
  /**
   * Dieser Konstruktor baut einen leeren Haufen.
   */
  public BinomialHeap() {
    /*
     * Todo
     */
  }
  
  /**
   * Diese Methode fügt einen Wert in den Haufen ein.
   * 
   * @param value der einzufügende Wert
   */
  public void insert(int value) {
    /*
     * Todo
     */
  }
  
  /**
   * Diese Methode ermittelt das minimale Element im binomialen
   * Haufen.
   * 
   * @return das minimale Element
   */
  public int min() {
    /*
     * Todo
     */
  }
  
  /**
   * Diese Methode entfernt das minimale Element aus dem binomialen
   * Haufen und gibt es zurück.
   * 
   * @return das minimale Element
   */
  public int deleteMin() {
    /*
     * Todo
     */
  }
}
