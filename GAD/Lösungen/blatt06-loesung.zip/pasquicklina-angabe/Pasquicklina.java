
public class Pasquicklina {
  public static void quicksort(int[] numbers, int threads) {
    /*
     * Todo
     */
  }
  
  public static void quicksort(int[] numbers) {
    /*
     * Todo
     */
  }
}
