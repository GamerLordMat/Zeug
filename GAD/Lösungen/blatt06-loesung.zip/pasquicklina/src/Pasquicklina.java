import java.util.Optional;
import java.util.function.BiFunction;
import java.util.function.Function;

public class Pasquicklina {
  private int[] numbers;

  public class Quicksort {
    /*
     * left und right speichern die minimalen Indices aller Schienen.
     */
    private Mutable<Optional<Integer>> left = new Mutable<>(Optional.empty());
    private Mutable<Optional<Integer>> right = new Mutable<>(Optional.empty());
    
    /*
     * Die Barriere synchronisiert die Threads.
     */
    private Barrier barrier;

    /*
     * Diese Variable speichert die Anzahl an Threads dieses rekursiven Aufrufs.
     */
    private int threads;

    /*
     * In 'next' werden die Zustände der kommenden Aufrufe aufgebaut.
     */
    private Quicksort[] next;

    /*
     * Ab 'from' wird sortiert.
     */
    int from;

    /*
     * Bis 'to' wird sortiert.
     */
    int to;

    void swap (int a, int b) {
      int t = numbers[a];
      numbers[a] = numbers[b];
      numbers[b] = t;
    }

    public Quicksort (int threads, int from, int to) {
      this.next = new Quicksort[2];
      this.barrier = new Barrier(threads);
      this.threads = threads;
      this.from = from;
      this.to = to;
    }

    public void quicksort (int id) {
      if (to - from <= 0)
        return;

      boolean addedThreadsLeft = false;
      boolean addedThreadsRight = false;

      int pivot = numbers[from];
      int leftIndex = from + 1 + id;
      int rightIndex = to + 1 - threads + (id - (to - from) % threads + threads) % threads;
      while (leftIndex <= rightIndex) {
        while (leftIndex <= rightIndex && numbers[leftIndex] <= pivot) {
          /*
           * Wir gehen in der Schiene zum nächsten Element.
           */
          leftIndex += threads;
          addedThreadsLeft = true;
        }
        while (leftIndex <= rightIndex && numbers[rightIndex] > pivot) {
          rightIndex -= threads;
          addedThreadsRight = true;
        }
        if (leftIndex < rightIndex)
          swap(leftIndex, rightIndex);
      }

      /*
       * Wir setzen leftIndex bzw. rightIndex. Wir müssen diesen Index genau auf ein Element
       * hinter dem jeweils letzten auf seiner Seite auf der Schiene setzen. Wenn wir
       * im letzten Schritt oben 'threads' aufaddiert haben, müssen wir dies also rückgängig
       * machen und durch 1 ersetzen.
       */
      if (addedThreadsLeft)
        leftIndex = leftIndex - threads + 1;
      if (addedThreadsRight)
        rightIndex = rightIndex + threads - 1;

      /*
       * Das aktuelle Thread gleicht nun seinen linken bzw. rechten Index mit den anderen Threads ab.
       */
      TrConsumer<Integer, Mutable<Optional<Integer>>, BiFunction<Integer, Integer, Integer>> updateLR =
        (index, leftOrRight, minMax) -> {
          if (threads == 1)
            leftOrRight.set(Optional.of(index));
          else
            synchronized (leftOrRight) {
              if (leftOrRight.get().isPresent())
                leftOrRight.set(Optional.of(minMax.apply(index, leftOrRight.get().get())));
              else
                leftOrRight.set(Optional.of(index));
            }
        };
      updateLR.accept(leftIndex, left, (a, b) -> Math.min(a, b));
      updateLR.accept(rightIndex, right, (a, b) -> Math.max(a, b));

      /*
       * Wir warten darauf, dass alle Threads mit dem Ausrichten fertig werden.
       */
      barrier.barrierWait();
      
      /*
       * Nun muss Thread 0 den Überlappungsbereich abarbeiten und den Zustand
       * für kommende Aufrufe vorbereiten.
       */

      int nextIndex = id < threads / 2 ? 0 : 1;
      int nextThreads;
      int nextId;
      if (threads == 1) {
        nextThreads = 1;
        nextId = 0;
      } else {
        nextId = id % (threads / 2);
        nextThreads = threads / 2;
      }

      if (id == 0) {
        leftIndex = left.get().get();
        rightIndex = right.get().get();
        while (leftIndex <= rightIndex) {
          while (leftIndex <= rightIndex && numbers[leftIndex] <= pivot) {
            leftIndex += 1;
          }
          while (leftIndex <= rightIndex && numbers[rightIndex] > pivot)
            rightIndex -= 1;
          if (leftIndex < rightIndex)
            swap(leftIndex, rightIndex);
        }
        left.set(Optional.of(leftIndex));

        swap(from, left.get().get() - 1);

        next[0] = new Quicksort(nextThreads, from, left.get().get() - 2);
        next[1] = new Quicksort(nextThreads, left.get().get(), to);
      }
      
      /*
       * Alle Threads warten auf Thread 0.
       */
      barrier.barrierWait();

      /*
       * Je nach ID unseres Threads und Anzahl von Threads steigen wir nach links
       * oder rechts ab.
       */
      if (nextIndex == 0 || threads == 1)
        next[0].quicksort(nextId);
      if (nextIndex == 1 || threads == 1)
        next[1].quicksort(nextId);
    }
  }

  private Quicksort first;

  private Pasquicklina (int threads, int[] numbers) {
    this.numbers = numbers;
    first = new Quicksort(threads, 0, numbers.length - 1);
  }

  private void quicksort (int id) {
    first.quicksort(id);
  }
  
  public static void quicksort(int[] numbers, int threads) {
    Pasquicklina pquick = new Pasquicklina(threads, numbers);

    /*
     * Wir starten 'threads - 1' Threads und nutzen den eigenen
     * Thread zusätzlich.
     */
    Thread[] others = new Thread[threads - 1];
    for (int i = 0; i < threads - 1; i++) {
      final int j = i;
      others[i] = new Thread( () -> {
        pquick.quicksort(j);
      });
      others[i].start();
    }
    pquick.quicksort(threads - 1);

    /*
     * Am Ende müssen wir auf die Beendigung aller Threads warten.
     */
    for (int i = 0; i < others.length; i++) {
      try {
        others[i].join();
      } catch (InterruptedException e) {
        e.printStackTrace();
      }
    }
  }
  
  public static void quicksort(int[] numbers) {
    quicksort(numbers, 1);
  }
}
