import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;

public class Master implements Runnable {
  private static Socket[] stores;

  private static HashString hash;

  private Socket client;

  public Master (Socket client) {
    this.client = client;
  }

  @Override public void run () {
    IRequest request;
    try {
      ObjectInputStream clientIn = new ObjectInputStream(client.getInputStream());
      request = (IRequest) clientIn.readObject();
    } catch (ClassNotFoundException e) {
      System.out.println("Error communicating with client!");
      try {
        client.close();
      } catch (IOException e1) {
      }
      return;
    } catch (IOException e) {
      System.out.println("Error communicating with client!");
      try {
        client.close();
      } catch (IOException e1) {
      }
      return;
    }
    System.out.println("Received : " + request);
    String key = request.getKey();
    int hash = Master.hash.hash(key);
    Socket store = stores[hash];
    IResponse response = null;
    synchronized (store) {
      try {
        ObjectOutputStream storeOut = new ObjectOutputStream(store.getOutputStream());
        storeOut.writeObject(request);
        storeOut.flush();

        ObjectInputStream storeIn = new ObjectInputStream(store.getInputStream());
        response = (IResponse) storeIn.readObject();
        System.out.println(response);
      } catch (ClassNotFoundException e) {
        System.out.println("Error communicating with store => exiting!");
        System.exit(1);
      } catch (IOException e) {
        System.out.println("Error communicating with store => exiting!");
        System.exit(1);
      }
    }
    try {
      ObjectOutputStream clientOut = new ObjectOutputStream(client.getOutputStream());
      clientOut.writeObject(response);
      clientOut.flush();
    } catch (IOException e) {
      System.out.println("Error communicating with client!");
    } finally {
      try {
        client.close();
      } catch (IOException e) {
      }
    }
  }

  public static void main (String[] args) throws IOException {
    /*
     * Configuration
     */
    int storeCount = 2;
    int storeServerPort = 5000;
    int clientServerPort = 5555;

    hash = new HashString(storeCount);
    stores = new Socket[storeCount];
    ServerSocket storeServer = new ServerSocket(storeServerPort);
    try {
      for (int i = 0; i < stores.length; i++) {
        stores[i] = storeServer.accept();
      }
    } finally {
      storeServer.close();
    }

    ServerSocket server = new ServerSocket(clientServerPort);

    try {
      while (true) {
        Socket client = server.accept();
        new Thread(new Master(client)).start();
      }
    } finally {
      server.close();
    }
  }
}
