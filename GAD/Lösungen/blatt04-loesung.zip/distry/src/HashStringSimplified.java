import java.util.ArrayList;
import java.util.Random;
import java.util.stream.LongStream;

/**
 * Die Klasse {@link HashStringSimplified} kann dazu verwendet werden,
 * Strings zu hashen.
 */
public class HashStringSimplified {
  private ArrayList<Long> a;

  private Random random;

  private int size;

  /**
   * Dieser Konstruktor initialisiert ein {@link HashStringSimplified}
   * Objekt für einen gegebenen Maximalwert (size - 1) der gehashten
   * Werte.
   * 
   * @param size die Größe der Hashtabelle
   */
  public HashStringSimplified (int size) {
    assert(size <= 65537);
    random = new Random();
    this.a = new ArrayList<>();
    this.size = size;
  }

  /**
   * Diese Methode berechnet den Hashwert für einen String.
   * 
   * @param key der Schlüssel, der gehasht werden sollen
   * @return der Hashwert des Schlüssels
   */
  public int hash (String key) {
    synchronized (a) {
      while (a.size() < key.length())
        /*
         * Wir vereinfachen hier, indem wir als Größe der Hashtabelle während
         * dem Skalarprodukt 65537 annehmen (sodass man nach Buchstaben aufteilen
         * darf). Bei der Korrektur ist es auch erlaubt, in Buchstaben zu unterteilen
         * und dennoch mit der Größe size zu rechnen, auch wenn das noch fälscher ist.
         */
        a.add((long)random.nextInt(65537));
    }
    long hash = LongStream.range(0, key.length()).map(i -> key.charAt((int)i) * a.get((int)i)).sum() % size;
    return (int)hash;
  }
}
