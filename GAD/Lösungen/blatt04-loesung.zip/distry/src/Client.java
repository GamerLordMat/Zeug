import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.Scanner;

public class Client {

  public static void main (String[] args) throws Exception {
    /*
     * Configuration
     */
    String masterHost = "127.0.0.1";
    int masterClientPort = 5555;
    
    Scanner scanner = new Scanner(System.in);
    String line = scanner.nextLine();
    scanner.close();
    String[] lineParts = line.split(" ");

    IRequest request;
    String key = lineParts[1];
    switch (lineParts[0]) {
      case "read": {
        request = new ReadRequest(key);
        break;
      }
      case "store": {
        int value = Integer.parseInt(lineParts[2]);
        request = new StoreRequest(key, value);
        break;
      }
      default: {
        throw new RuntimeException("Invalid command!");
      }
    }

    System.out.println("Sending: " + request);

    Socket master = new Socket(masterHost, masterClientPort);
    try {
      ObjectOutputStream out = new ObjectOutputStream(master.getOutputStream());
      out.writeObject(request);
      out.flush();

      ObjectInputStream in = new ObjectInputStream(master.getInputStream());
      IResponse response = (IResponse) in.readObject();
      ResponseVisitor rv = new ResponseVisitor();
      rv.__( (readResponse) -> {
        SerializableOptional<Integer> result = readResponse.getValue();
        if(result.isPresent())
          System.out.println("Read response with value " + result.get() + ".");
        else
          System.out.println("Read response: Unknown key!");
      }, (storeResponse) -> {
        System.out.println("Store successful!");
      });
      response.accept(rv);
    } finally {
      master.close();
    }
  }

}
