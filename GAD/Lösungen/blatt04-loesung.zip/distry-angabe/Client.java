
public class Client {

  public static void main (String[] args) {
    /*
     * Configuration
     */
    String masterHost = "127.0.0.1";
    int masterClientPort = 5555;

    /*
     * Todo
     */
  }
}
