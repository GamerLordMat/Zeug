
public class Store {

  public static void main (String[] args) {
    /*
     * Configuration
     */
    String masterHost = "127.0.0.1";
    int masterStorePort = 5000;
    
    /*
     * Todo
     */
  } 
}
