
public class Master {

  public static void main (String[] args) throws IOException {
    /*
     * Configuration
     */
    int storeCount = 2;
    int storeServerPort = 5000;
    int clientServerPort = 5555;

    /*
     * Todo
     */
  }
}
