
public class MazeSolutionRightHand {
  private static boolean[][] maze;
  private static int goalX, goalY;

  private static boolean[][] visited; // current path

  static class Position {
    private final int x;

    public int getX() {
      return x;
    }

    private final int y;

    public int getY() {
      return y;
    }

    public Position(int x, int y) {
      this.x = x;
      this.y = y;
    }

    Position move(Direction dir) {
      switch (dir) {
      case UP: {
        return new Position(x - 1, y);
      }
      case DOWN: {
        return new Position(x + 1, y);
      }
      case LEFT: {
        return new Position(x, y - 1);
      }
      case RIGHT: {
        return new Position(x, y + 1);
      }
      }
      throw new RuntimeException();
    }

    boolean valid() {
      return x > 0 && y > 0 && x < maze.length && y < maze[0].length;
    }

    boolean wall() {
      return x < 0 || y < 0 || x >= maze.length || y >= maze[0].length || maze[x][y];
    }

    boolean entry() {
      return x == 1 && y == 0;
    }

    boolean exit() {
      return x == goalX && y == goalY;
    }

    @Override
    public String toString() {
      return "(" + x + "|" + y + ")";
    }
  }

  static enum Direction {
    RIGHT, DOWN, LEFT, UP;

    Direction toRight() {
      return Direction.values()[(this.ordinal() + 1) % 4];
    }

    Direction toLeft() {
      return Direction.values()[(this.ordinal() + 3) % 4];
    }

    Direction toOpposite() {
      return Direction.values()[(this.ordinal() + 2) % 4];
    }
  }

  public static void main(String[] args) {
    int width = 10;
    int height = 10;
    maze = Maze.generateMaze(height, width);

//    int width = 11;
//    int height = 11;
//    maze = Maze.generateStandardMaze();

    goalX = height - 1;
    goalY = width - 2;

    // Here we store which fields have been visited already:
    visited = new boolean[maze.length][maze[0].length];

    Maze.draw(1, 0, maze, visited);

    // We start at the initial position going right
    boolean res = new Walker(new Position(1, 0), Direction.RIGHT).walk();

    if (!res) // Have we found any sols?
      System.out.println("Ahhhh... no way out!");
    else {
      Maze.draw(goalX, goalY, maze, visited);
      System.out.println("Finished!");
    }
  }
  
  /*
   * 1. Fall (geradeaus) (a):
   * |---------|
   * |         |
   * |  x      |
   * |###      |
   * |---------|
   * 
   * 1. Fall (geradeaus) (b):
   * |---------|
   * |         |
   * |   x     |
   * |###      |
   * |---------|
   *
   * 1. Fall (geradeaus) (c):
   * |---------|
   * |         |
   * |  x      |
   * |####     |
   * |---------|
   * 
   * 2. Fall (links) (a):
   * |---------|
   * |         |
   * |  x#     |
   * |####     |
   * |---------|
   * 
   * 2. Fall (links) (b):
   * |---------|
   * |  x      |
   * |   #     |
   * |####     |
   * |---------|
   * 
   * 2. Fall (links) (c):
   * |---------|
   * |   #     |
   * |  x#     |
   * |####     |
   * |---------|
   * 
   * 3. Fall (rückwärts) (a):
   * |---------|
   * |  ##     |
   * |  x#     |
   * |####     |
   * |---------|
   * 
   * 3. Fall (rückwärts) (b):
   * |---------|
   * |  ##     |
   * | x #     |
   * |####     |
   * |---------|
   * 
   * 3. Fall (rückwärts) (c):
   * |---------|
   * | ###     |
   * |  x#     |
   * |####     |
   * |---------|
  */
  
  static class Walker {
    private Position pos;

    private Direction dir;

    public Walker(Position pos, Direction dir) {
      this.pos = pos;
      this.dir = dir;
    }

    private boolean tryWalk(Direction dir) {
      System.out.println("Trying direction " + dir);
      if (!pos.move(dir).wall()) {
        System.out.println("Case a/c");
        this.dir = dir;
        pos = pos.move(dir);
        if (!pos.move(dir.toRight()).wall()) {
          System.out.println("Case a");
          this.dir = dir.toRight();
        }
        return true;
      } else
        return false;
    }

    public boolean walk() {
      boolean exit;
      do {
        System.out.println("Next position: " + pos + ", direction: " + dir);
        visited[pos.getX()][pos.getY()] = true;

        if (!pos.move(dir.toRight()).wall()) {
          System.out.println("Fall *b");
          pos = pos.move(dir);
        } else if (!tryWalk(dir) && !tryWalk(dir.toLeft()) && !tryWalk(dir.toOpposite()))
          throw new RuntimeException("We cannot go nowhere, this is not good :-/");

        Maze.draw(goalX, goalY, maze, visited);
        try {
          Thread.sleep(250);
        } catch (InterruptedException e) {
          e.printStackTrace();
        }

        exit = pos.exit();
      } while (!exit && !pos.entry());
      return exit;
    }
  }
}
