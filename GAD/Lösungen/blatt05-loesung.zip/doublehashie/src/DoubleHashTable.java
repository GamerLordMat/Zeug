import java.lang.reflect.Array;
import java.util.*;

/**
 * Die Klasse DoubleHashTable implementiert eine Hashtabelle, die doppeltes
 * Hashing verwendet.
 *
 * @param <K> der Typ der Schlüssel, die in der Hashtabelle gespeichert werden
 * @param <V> der Typ der Werte, die in der Hashtabelle gespeichert werden
 */
public class DoubleHashTable<K, V> {
  private int maxRehashes = 0;
  
  DoubleHashable<K> hasher;

  private Pair<K, V>[] hashTable;

  /**
   * Diese Methode implementiert h(x, i).
   * 
   * @param key der Schlüssel, der gehasht werden soll
   * @param i der Index, der angibt, der wievielte Hash für den gegebenen Schlüssel
   * berechnet werden soll
   * @return der generierte Hash
   */
  private int hash(K key, int i) {
    if(i > maxRehashes)
      maxRehashes = i;
    int hash = (int) ((hasher.hash(key) + i*hasher.hashTick(key)) % hashTable.length);
    return hash;
  }

  /**
   * Dieser Konstruktor initialisiert die Hashtabelle.
   * 
   * @param primeSize die Größe 'm' der Hashtabelle; es kann davon ausgegangen
   * werden, dass es sich um eine Primzahl handelt.
   * @param hashableFactory Fabrik, die aus einer Größe ein DoubleHashable<K>-Objekt erzeugt.
   */
  public DoubleHashTable(int primeSize, HashableFactory<K> hashableFactory) {
    Random r = new Random();
    this.hashTable = (Pair<K, V>[]) Array.newInstance(Pair.class,
        primeSize);
    this.hasher = hashableFactory.create(primeSize);

    // Random r = new Random();
    // a = r.nextInt(primeSize - 1) + 1;
  }

  /**
   * Diese Methode fügt entsprechend des doppelten Hashens ein Element
   * in die Hashtabelle ein.
   * 
   * @param k der Schlüssel des Elements, das eingefügt wird
   * @param v der Wert des Elements, das eingefügt wird
   * @return 'true' falls das einfügen erfolgreich war, 'false' falls die
   * Hashtabelle voll ist.
   */
  public boolean insert(K k, V v) {
    for (int i = 0; i < hashTable.length; i++) {
      int hashed = hash(k, i);
      if (hashTable[hashed] == null || hashTable[hashed]._1.equals(k)) {
        hashTable[hashed] = new Pair<K, V>(k, v);
        return true;
      }
    }
    return false;
  }

  /**
   * Diese Methode sucht ein Element anhand seines Schlüssels in der Hashtabelle
   * und gibt den zugehörigen Wert zurück, falls der Schlüssel gefunden wurde.
   * 
   * @param k der Schlüssel des Elements, nach dem gesucht wird
   * @return der Wert des zugehörigen Elements, sonfern es gefunden wurde
   */
  public Optional<V> find(K k) {
    for (int i = 0; i < hashTable.length; i++) {
      int hashed = hash(k, i);
      if (hashTable[hashed] == null)
        return Optional.empty();
      else if (hashTable[hashed]._1.equals(k))
        return Optional.of(hashTable[hashed]._2);
    }
    return Optional.empty();
  }

  /**
   * Diese Methode ermittelt die Anzahl der Kollisionen, also die Anzahl
   * der Elemente, nicht an der 'optimalen' Position in die Hashtabelle eingefügt
   * werden konnten. Die optimale Position ist diejenige Position, die der
   * erste Aufruf der Hashfunktion (i = 0) bestimmt.
   * 
   * @return die Anzahl der Kollisionen
   */
  public int collisions() {
    int n = 0;
    for (int i = 0; i < hashTable.length; i++)
      if (hashTable[i] != null && i != hash(hashTable[i]._1, 0))
        n++;
    return n;
  }
 
  /**
   * Diese Methode berechnet die maximale Anzahl von Aufrufen der Hashfunktion,
   * die nötig waren, um ein einziges Element in die Hashtabelle einzufügen.
   * 
   * @return die berechnete Maximalzahl von Aufrufen
   */
  public int maxRehashes() {
    return this.maxRehashes;
  }
}
