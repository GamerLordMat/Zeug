import java.util.ArrayList;
import java.util.Random;
import java.util.stream.LongStream;

/**
 * Die Klasse {@link DoubleHashString} kann dazu verwendet werden,
 * Strings zu hashen.
 */
public class DoubleHashString implements DoubleHashable<String> {
  private ArrayList<Long> a;
  private ArrayList<Long> b;

  private Random random;

  private int size;

  /**
   * Dieser Konstruktor initialisiert ein {@link DoubleHashString}
   * Objekt für einen gegebenen Maximalwert (size - 1) der gehashten
   * Werte.
   * 
   * @param size die Größe der Hashtabelle
   */
  public DoubleHashString (int size) {
    assert(size <= 65537);
    random = new Random();
    this.a = new ArrayList<>();
    this.b = new ArrayList<>();
    this.size = size;
  }
  
  public long hash (String key, boolean tick) {
    ArrayList<Long> v = tick ? b : a;
    while (v.size() < key.length())
      v.add((long)random.nextInt(65537));
    long mod = tick ? size - 1 : size;
    long offset = tick ? 1 : 0;
    long hash = (LongStream.range(0, key.length()).map(i -> key.charAt((int)i) * a.get((int)i)).sum() % mod) + offset;
    return hash;
  }

  /**
   * Diese Methode berechnet h(key) für einen String.
   * 
   * @param key der Schlüssel, der gehasht werden soll
   * @return der Hashwert des Schlüssels
   */
  public long hash (String key) {
    return hash(key, false);
  }
  

  /**
   * Diese Methode berechnet h'(key) für einen String.
   * 
   * @param key der Schlüssel, der gehasht werden soll
   * @return der Hashwert des Schlüssels
   */
  public long hashTick (String key) {
    return hash(key, true);
  }
}
