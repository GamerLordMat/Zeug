import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Random;


public class Program {

  public static void main (String[] args) {
    DoubleHashTable<Integer, Integer> ht = new DoubleHashTable<>(997, new IntHashableFactory());
    
    Hashtable<Integer, Integer> htJava = new Hashtable<>();
    
    Random r = new Random();
    
    for(int i = 0; i < 500; i++) {
      int key = r.nextInt(Integer.MAX_VALUE);
      while(htJava.contains(key))
        key = r.nextInt(Integer.MAX_VALUE);
      int value = r.nextInt(Integer.MAX_VALUE);
      
      System.out.println("Insert entry: " + key + " -> " + value);
      
      if(!ht.insert(key, value))
        throw new RuntimeException("Unable to insert :-/");
      htJava.put(key, value);
    }
    
    Iterator<Entry<Integer, Integer>> it = htJava.entrySet().iterator();
    while(it.hasNext()) {
      Entry<Integer, Integer> entry = it.next();
      
      System.out.println("Next entry: " + entry.getKey() + " -> " + entry.getValue());
      
      if(!entry.getValue().equals(ht.find(entry.getKey()).get()))
        throw new RuntimeException("fooo");
    }
    
    System.out.println("Collisions: " + ht.collisions());
    System.out.println("Rehashes: " + ht.maxRehashes());
  }

}
