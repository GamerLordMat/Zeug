import java.util.Random;

/**
 * Die Klasse {@link DoubleHashInt} kann dazu verwendet werden,
 * Integer zu hashen.
 */
public class DoubleHashInt implements DoubleHashable<Integer> {
  private long a;
  private long b;

  private int size;
  

  /**
   * Dieser Konstruktor initialisiert ein {@link DoubleHashInt}
   * Objekt für einen gegebenen Maximalwert (size - 1) der gehashten
   * Werte.
   * 
   * @param size die Größe der Hashtabelle
   */
  public DoubleHashInt (int size) {
    Random r = new Random();
    this.a = r.nextInt(size - 1) + 1;
    this.b = r.nextInt(size - 1) + 1;
    this.size = size;
  }

  /**
   * Diese Methode berechnet h(key) für einen Integer.
   * 
   * @param key der Schlüssel, der gehasht werden soll
   * @return der Hashwert des Schlüssels
   */
  @Override public long hash (Integer key) {
    long keyLong = key;
    keyLong &= 0xFFFFFFFFl; //Interpret as unsigned int
    long hash = (a*keyLong) % size;
    return hash;
  }

  /**
   * Diese Methode berechnet h'(key) für einen Integer.
   * 
   * @param key der Schlüssel, der gehasht werden soll
   * @return der Hashwert des Schlüssels
   */
  @Override public long hashTick (Integer key) {
    long keyLong = key;
    keyLong &= 0xFFFFFFFFl; //Interpret as unsigned int
    long hash = (b*keyLong) % (size - 1) + 1;
    return hash;
  }

}
